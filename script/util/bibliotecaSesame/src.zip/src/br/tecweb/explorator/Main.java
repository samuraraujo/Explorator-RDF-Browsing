package br.tecweb.explorator;


/**
 * Classe respons�vel por passar o URI de entrada e chamar os m�todos da
 * Biblioteca
 * 
 * @author Danielle Loyola Santos, Samur Araujo
 * @version 1.1
 */
public class Main {
	/**
	 * M�todo que chama os m�todos da Biblioteca e passa o URI de entrada
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			SesameApiRubyAdapter saver = new SesameApiRubyAdapter();
			saver.loaduri("http://richard.cyganiak.de/foaf.rdf#cygri", true);
			 String x = saver.query("SELECT DISTINCT ?s ?p ?o WHERE {  { ?s ?p ?o } .   }  " );
			 System.out.println(x);
			 
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.toString());
		}
	}
}
